﻿namespace _02_CustomerSupport
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Support supportCenter = new Support();
            supportCenter.Start();
        }
    }
}
